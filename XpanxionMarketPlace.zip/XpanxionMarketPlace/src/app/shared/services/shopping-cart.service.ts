import { Observable } from 'rxjs';
import {AngularFirestore} from '@angular/fire/firestore'
import { ShoppingCart } from '../models/shopping-cart';
import { Product } from '../models/product';
import { AngularFireDatabase } from '@angular/fire/database';
import { Injectable } from '@angular/core';
import { map, tap, take, switchMap, mergeMap, expand, takeWhile } from 'rxjs/operators';

@Injectable({providedIn: 'root'})
export class ShoppingCartService {
  items: any

  constructor(private firestore: AngularFirestore, private db: AngularFireDatabase) { }

  async getCart() {
    
    

    let cartId = await this.getOrCreateCartId();
    return this.db.object('/shopping-carts/' + cartId).snapshotChanges().pipe(
      map(x => new ShoppingCart(this.items)));
  }

  async addToCart(product: Product) { 
    this.updateItem(product, 1);
  }

  async removeFromCart(product: Product) {
    this.updateItem(product, -1);
  }

  async clearCart() { 
    let cartId = await this.getOrCreateCartId();
    this.firestore.doc('shopping-carts/' + cartId + '/items').delete();
  }
  

  private create() { 
    return this.db.list('/shopping-carts').push({
      dateCreated: new Date().getTime()
    });
  }

  private getItem(cartId: string, productId: string) {
    return this.firestore.doc('shopping-carts/' + cartId + '/items/' + productId).snapshotChanges();
  }

  private async getOrCreateCartId(): Promise<string> { 
    let cartId = localStorage.getItem('cartId');
    if (cartId) return cartId; 

    let result = await this.create();
    localStorage.setItem('cartId', result.key);
    return result.key;   
  }

  private async updateItem(product: Product, change: number) {
    let cartId = await this.getOrCreateCartId();
    let item$ = this.getItem(cartId, product.$key);
    item$.pipe(take(1)).subscribe(item => {
      let quantity = (item.payload.data['quantity'] || 0) + change;
      if (quantity === 0) item.payload.ref.delete();
      else item.payload.ref.update({ 
        title: product.title,
        imageUrl: product.imageUrl,
        price: product.price,
        quantity: quantity
      });
    });
  }
}
