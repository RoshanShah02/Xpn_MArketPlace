import { ShoppingCartService } from './shopping-cart.service';
import {AngularFirestore} from '@angular/fire/firestore'
import { AngularFireDatabase } from '@angular/fire/database';
import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class OrderService {

  constructor(private firestore: AngularFirestore, private db: AngularFireDatabase, private shoppingCartService: ShoppingCartService) { }

  async placeOrder(order) {
    let result = await this.db.list('/orders').push(order);
    this.shoppingCartService.clearCart();
    return result;
  }

  getOrders() { 
    return this.firestore.collection('orders').snapshotChanges();
  }

  getOrdersByUser(userId: string) {
    return this.db.list('/orders').query.orderByChild('userId').equalTo(userId);
  }
}
