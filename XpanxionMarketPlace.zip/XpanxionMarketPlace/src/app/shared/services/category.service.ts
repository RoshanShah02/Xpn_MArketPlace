import { AngularFireDatabase } from '@angular/fire/database';
import {AngularFirestore} from '@angular/fire/firestore'
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';

@Injectable({providedIn: 'root'})
export class CategoryService {

  constructor(private db: AngularFireDatabase, private firestore: AngularFirestore) { }

  getAll() { 
    return this.db.list('/categories').valueChanges();
    //return this.db.list('/categories').valueChanges();
  }

  getAllforDropDown() { 
    return this.db.list('/categories', ref => ref.orderByChild('name'))
    .snapshotChanges()
    .pipe(map(categories => 
      { 
        return categories.map(c => 
          ({ key: c.payload.key, value: c.payload.val()['name']
          }));  
        }));
    //return this.db.list('/categories').valueChanges();
  }
}
