import { AppUser } from '../models/app-user';
import { AngularFireDatabase } from '@angular/fire/database';
import {AngularFirestore} from '@angular/fire/firestore'
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs'
import * as firebase from 'firebase'; 
import { AngularFireObject } from '@angular/fire/database';

@Injectable({providedIn: 'root'})
export class UserService {

  constructor(private db: AngularFireDatabase, private firestore: AngularFirestore ) { }

  save(user: firebase.User) {
    this.db.object('/users/' + user.uid).update({
      name: user.displayName,
      email: user.email
    });
  }

  get(uid: string): AngularFireObject<AppUser> { 
    return this.db.object('/users/' + uid);
  }
}
