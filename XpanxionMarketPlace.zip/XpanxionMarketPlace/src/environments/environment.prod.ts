export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAwRjtPNRdETYvlZd_QHvNGkFz788IYokc",
    authDomain: "xpanxionmarketplace-e2c0a.firebaseapp.com",
    databaseURL: "https://xpanxionmarketplace-e2c0a.firebaseio.com",
    projectId: "xpanxionmarketplace-e2c0a",
    storageBucket: "xpanxionmarketplace-e2c0a.appspot.com",
    messagingSenderId: "859598747098",
    appId: "1:859598747098:web:187af6be57e33a6b777ce3",
    measurementId: "G-55DE48SET4" 
  }
};
